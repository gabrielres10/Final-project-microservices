// Esta clase ha sido eliminada porque su funcionalidad (Bean RestTemplate) 
// ya está definida en FutureXCourseCatalogApplication.java
// Eliminar esta clase resuelve el conflicto de definición duplicada de beans
