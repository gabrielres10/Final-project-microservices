package com.futurex.services.FutureXCourseApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FutureXCourseAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
